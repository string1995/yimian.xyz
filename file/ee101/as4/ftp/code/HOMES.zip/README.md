# ee101-as4-hotelsystem
# gcc! gcc! gcc!